+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#4          |
|	 Due: 03/27/12         |
+==============================+

This zip file contains: a4main.py, a4input1.txt, a4input2.txt, a4input3.txt, a4input4.txt, README.txt, tpg.py

To run "a4main.py" on Windows OS:
1) Go to the Windows Command Prompt
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like: python.exe a4main.py a4input1.txt

CREDITS/REFERENCES:
http://docs.python.org/py3k/tutorial/index.html
sbcsppl Q&A group

NOTES:
1) I handled the left-hand assignments in 2 ways: for the variable, I simply created a method that returns the name of the variable as it is the 'key' in the dictionary; for the array location, I created a method that will access the value of the 'key' from the global/local variables and set the value there.

2) I made a minor change to the eval method: I added the 'localvars' parameter so that it will correctly access the localvars in nested statements.