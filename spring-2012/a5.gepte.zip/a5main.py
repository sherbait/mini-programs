import sys
import tpg

class EvalError(Exception):
    """Class of exceptions raised when an error occurs during evaluation."""

class AnalError(Exception):
    """Class of exceptions raised when an error occurs during analysis."""

# These are the classes of nodes of our abstract syntax trees (ASTs).

class Node(object):
    """Base class of AST nodes."""

    # For each class of nodes, store names of the fields for children nodes.
    fields = []

    def __init__(self, *args):
        """Populate fields named in "fields" with values in *args."""
        assert(len(self.fields) == len(args))
        for f, a in zip(self.fields, args): setattr(self, f, a)

    def eval(self, localvars):
        """Evaluate the AST node, called on nodes of expression subclasses."""
        raise Exception("Not implemented.")

    def exec(self, localvars, gscope):
        """Evaluate the AST node, called on nodes of statement subclasses."""
        raise Exception("Not implemented.")

# subclasses of Node for expressions

class Var(Node):
    """Class of nodes representing accesses of variable."""
    fields = ['name']

    def eval(self, localvars):
        if self.name in globalvars: return globalvars[self.name]
        elif self.name in localvars: return localvars[self.name]
        else: raise EvalError()

    def getloc(self):
        return self.name
    
class Int(Node):
    """Class of nodes representing integer literals."""
    fields = ['value']

    def eval(self, localvars): return self.value
    
class String(Node):
    """Class of nodes representing string literals."""
    fields = ['value']

    def eval(self, localvars): return self.value
    
class Array(Node):
    """Class of nodes representing array literals."""
    fields = ['elements']

    def eval(self, localvars):
        return [e.eval(localvars) for e in self.elements]

class Index(Node):
    """Class of nodes representing indexed accesses of arrays or strings."""
    fields = ['indexable','index']

    def eval(self, localvars):
        v1 = self.indexable.eval(localvars)
        v2 = self.index.eval(localvars)

        if not isinstance(v1,(str,list)): raise EvalError()
        if not isinstance(v2,int): raise EvalError()
        if v2 > len(v1): raise EvalError()

        return v1[v2]

    def setval(self, value, localvars, gscope):
        v1 = self.indexable.eval(localvars)
        v2 = self.index.eval(localvars)

        if not isinstance(v1,(str,list)): raise EvalError()
        if not isinstance(v2,int): raise EvalError()
        if v2 > len(v1): raise EvalError()

        if isinstance(self.indexable, Var):
            loc = self.indexable.getloc()
            if gscope: globalvars[loc][v2] = value
            elif loc in globalvars: globalvars[loc][v2] = value
            else: localvars[loc][v2] = value

class BinOpExp(Node):
    """Class of nodes representing binary-operation expressions."""
    fields = ['left', 'op', 'right']

    def eval(self, localvars):
        v1 = self.left.eval(localvars)
        v2 = self.right.eval(localvars)

        if self.op == '+': 
            if isinstance(v1,int) and isinstance(v2,int): return v1 + v2
            if isinstance(v1,str) and isinstance(v2,str): return v1 + v2
            raise EvalError()

        if not isinstance(v1,int): raise EvalError()
        if not isinstance(v2,int): raise EvalError()

        if self.op == '-': return v1 - v2
        if self.op == '*': return v1 * v2

        if self.op == '/': 
            if v2 ==0: raise EvalError()
            return int(v1 / v2)

        if self.op == '==': return 1 if v1 == v2 else 0
        if self.op == '<':  return 1 if v1 < v2 else 0
        if self.op == '>':  return 1 if v1 > v2 else 0

        if self.op == 'and': return 1 if v1 and v2 else 0
        if self.op == 'or':  return 1 if v1 or v2 else 0
    
class UniOpExp(Node):
    """Class of nodes representing unary-operation expressions."""
    fields = ['op', 'arg']

    def eval(self, localvars):
        v = self.arg.eval(localvars)
        if not isinstance(v,int): raise EvalError()

        if self.op == 'not': return 0 if v else 1

# subclasses of Node for statements

class Print(Node):
    """Class of nodes representing print statements."""
    fields = ['exp']

    def exec(self, localvars, gscope): print(repr(self.exp.eval(localvars)))

class Assign(Node):
    """Class of nodes representing assignment statements."""
    fields = ['left', 'right']

    def exec(self, localvars, gscope):
        right = self.right.eval(localvars)
        
        # left side of assignment is a variable location
        if isinstance(self.left, Var):
            left = self.left.getloc()
            if gscope: globalvars[left] = right
            elif left in globalvars: globalvars[left] = right
            else: localvars[left] = right
            
        # left side of assignment is an array location
        if isinstance(self.left, Index):
            self.left.setval(right, localvars, gscope)
    
class Block(Node):
    """Class of nodes representing block statements."""
    fields = ['stmts']

    def exec(self, localvars, gscope):
        for i in self.stmts: i.exec(localvars, gscope)

class If(Node):
    """Class of nodes representing if statements."""
    fields = ['exp', 'stmt']

    def exec(self, localvars, gscope):
        if self.exp.eval(localvars) != 0: self.stmt.exec(localvars, gscope)

class While(Node):
    """Class of nodes representing while statements."""
    fields = ['exp', 'stmt']

    def exec(self, localvars, gscope):
        exp = self.exp.eval(localvars)
        if exp == 0: return  # terminate while loop
        self.stmt.exec(localvars, gscope)  # execute the body statement if expression is true
        self.exec(localvars, gscope)  # repeat execution of while

class Def(Node):
    """Class of nodes representing procedure definitions."""
    fields = ['name', 'params', 'body']

    def exec(self, localvars, gscope):
        if self.name in procedures: raise EvalError()  # procedure must not have been defined
        for i in self.params:  # parameters must not shadow variables in global scope
            if i in globalvars: raise EvalError()
        procedures[self.name] = [self.params, self.body]  # associate the name with definitions

class Call(Node):
    """Class of nodes representing precedure calls."""
    fields = ['name', 'args']

    def exec(self, localvars, gscope):
        if self.name not in procedures: raise EvalError()  # procedure must have been defined
        procedure = procedures[self.name]  # get the procedure definitions
        if len(procedure[0]) != len(self.args): raise EvalError()  # no. of arguments of call must equal no. of parameters
        
        argvalues = []
        for i in self.args: argvalues.append(i.eval(localvars))  # evaluate each argument in order
        self.localvars = dict(zip(procedure[0], argvalues))  # local variables are set

        # execution of body means local variables are now in effect
        gscope = False
        procedure[1].exec(self.localvars, gscope)
        # after execution it goes back to global
        gscope = True
        self.localvars = {}  # remove local variables after procedure execution


class Parser(tpg.Parser):
    r"""
    token int:         '\d+' ;
    token string:      '\"[^\"]*\"' ;
    token ident:       '[a-zA-Z_][\w]*' ;
    separator spaces:  '\s+' ;
    separator comment: '#.*' ;

    START/s -> Stmt/s ;

    Stmt/s ->
    ( 'print' Exp/e ';'  $s = Print(e)$
    | Exp/l '=(?!=)' Exp/r ';'  $ s = Assign(l, r) $
    | '\{'  $ s=[] $  ( Stmt/s2  $ s.append(s2) $  )* '\}'  $s = Block(s)$
    | 'if' '\(' Exp/e '\)' Stmt/s  $ s = If(e, s) $
    | 'while' '\(' Exp/e '\)' Stmt/s  $ s = While(e, s) $

    | 'def' ident/f '\('  $l=[]$  ( ident/i  $l.append(i)$
                                    ( ',' ident/i  $l.append(i)$  )*)? '\)'
      Stmt/s2  $s=Def(f,l,s2)$
    | ident/f '\('  $l=[]$  ( Exp/e  $l.append(e)$
                              ( ',' Exp/e  $l.append(e)$  )*)? '\)' ';'
      $s=Call(f,l)$
    ) ;

    Exp/e -> Or/e ;
    Or/e -> And/e ( 'or' And/e2  $e=BinOpExp(e,'or',e2)$  )* ;
    And/e -> BoolAtom/e ( 'and' BoolAtom/e2  $e=BinOpExp(e,'and',e2)$  )* ;
    BoolAtom/e -> 'not' BoolAtom/e $e=UniOpExp('not', e)$  | Test/e ;
    Test/e -> Add/e ( TestOp Add/e2  $e=BinOpExp(e,TestOp,e2)$  )* ;
    Add/e -> Mul/e ( AddOp Mul/e2  $e=BinOpExp(e,AddOp,e2)$  )* ; 
    Mul/e -> Index/e ( MulOp Index/e2  $e=BinOpExp(e,MulOp,e2)$  )* ;
    Index/e -> Atom/e ( '\[' Exp/e2 '\]'  $e=Index(e,e2)$  )* ;
    Atom/e -> 
    '\(' Exp/e '\)'
    | int/i  $e=Int(int(i))$
    | string/s  $e=String(s[1:-1])$
    | '\['  $e=[]$  ( Exp  $e.append(Exp)$  ( ',' Exp  $e.append(Exp)$  )*)?
      '\]'  $e=Array(e)$
    | ident  $e=Var(ident)$
    ;
    TestOp/r ->  '=='/r | '<'/r | '>'/r ;
    AddOp/r ->   '\+'/r | '-'/r ;
    MulOp/r ->   '\*'/r | '/'/r ;
    """

def parse(code):
    # This makes a parser object, which acts as a parsing function.
    parser = Parser()
    return parser(code)


def analproc0(node):
    """Analyze procedure definitions and calls."""
    if isinstance(node, (Print,Assign)): pass
    elif isinstance(node, Block):
        for s in node.stmts: analproc0(s)
    elif isinstance(node, (If,While)):
        analproc0(node.stmt)
    elif isinstance(node, Def):
        if node.name in procnames: print("Analysis Error")
        else:
            print('Definition of procedure', node.name)
            procnames.add(node.name)
            analproc0(node.body)
    elif isinstance(node, Call):
        if node.name not in procnames: print("Analysis Error")
        else: print('Call of procedure', node.name)
    else: raise Exception("Not implemented.")


def analvar0(node, localvarnames, gscope):
    """Analyze variable definitions and uses."""
    if isinstance(node, Var): 
        if node.name not in globalvarnames and node.name not in localvarnames:
            print("Analysis Error")
        else: print('Use of variable', node.name)
    elif isinstance(node, (Int,String)): pass
    elif isinstance(node, Array):
        for e in node.elements: analvar0(e, localvarnames, gscope)
    elif isinstance(node, Index):
        analvar0(node.indexable, localvarnames, gscope)
        analvar0(node.index, localvarnames, gscope)
    elif isinstance(node, BinOpExp):
        analvar0(node.left, localvarnames, gscope)
        analvar0(node.right, localvarnames, gscope)
    elif isinstance(node, UniOpExp):
        analvar0(node.arg, localvarnames, gscope)
    elif isinstance(node, Print):
        analvar0(node.exp, localvarnames, gscope)
    elif isinstance(node, Assign):
        analvar0(node.right, localvarnames, gscope)
        if isinstance(node.left, Var):
            if gscope: globalvarnames.add(node.left.name)
            else: localvarnames.add(node.left.name)
            print('Definition of variable', node.left.name)
        else: # isinstance(self.left,Index) or otherwise # type error ignored
            analvar0(node.left, localvarnames, gscope)
    elif isinstance(node, Block):
        for s in node.stmts: analvar0(s, localvarnames, gscope)
    elif isinstance(node, (If,While)):
        analvar0(node.exp, localvarnames, gscope)
        analvar0(node.stmt, localvarnames, gscope)
    elif isinstance(node, Def):
        newlocalvarnames = set(node.params)
        if newlocalvarnames & globalvarnames: print("Analysis Error")
        else:
            print('New locals of procedure', node.name+':', ', '.join(node.params))
            analvar0(node.body, newlocalvarnames, False)
    elif isinstance(node, Call):
        for a in node.args: analvar0(a, localvarnames, gscope)
    else: raise Exception("Not implemented.")


# Below is the driver code, which parses a given MustScript program,
# analyzes the procedure and variable names, and executes the program.

# Open the input file, and read in the input program.
prog = open(sys.argv[1]).read()

try:
    # Try to parse the program.
    print('Parsing...')
    node = parse(prog)

    # Try to analyze the program.
    print('Analyzing...')
    # set up and call method for analyzing procedures:
    procnames = set()
    analproc0(node)
    # set up and call method for analyzing variables:
    globalvarnames, localvarnames, gscope = set(), set(), True
    analvar0(node, localvarnames, gscope)

    # Try to execute the program.
    print('Executing...')
    # set up and call method for analyzing variables:
    procedures = {}
    globalvars = {}
    # globalvars, localvars, gscope = {}, {}, True
    # exec0(node, localvars, gscope)
    node.exec({}, True)
    

# If an exception is rasied, print the appropriate error.
except tpg.Error:
    print('Parsing Error')

    # Uncomment the next line to re-raise the parsing error,
    # displaying where the error occurs.  Comment it for submission.

    # raise

except AnalError as e:
    print('Analysis Error')

    # Uncomment the next line to re-raise the evaluation error, 
    # displaying where the error occurs.  Comment it for submission.

    # raise

except EvalError:
    print('Evaluation Error')

    # Uncomment the next line to re-raise the evaluation error, 
    # displaying where the error occurs.  Comment it for submission.

    # raise
