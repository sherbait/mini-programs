+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#5          |
|	 Due: 04/14/12         |
+==============================+

This zip file contains: a5main.py, a5input0.txt, a5input1.txt, a5input2.txt, a5input3.txt, a5input4.txt, README.txt, tpg.py

To run "a5main.py" on Windows OS:
1) Go to the Windows Command Prompt
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like: python.exe a5main.py a5input1.txt

CREDITS/REFERENCES:
a4main.py

NOTES:
I took my working solution from homework 4 to handle the execution part of this assignment. There, I used functional paradigm mainly because of the relatively more complicated solutions for recursion and evaluation. I also had a few methods in the classes that are called upon by other classes to handle the left-hand assignments.