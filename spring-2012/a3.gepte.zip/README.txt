+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#3          |
|	 Due: 03/06/12         |
+==============================+

This zip file contains: a3main.py, a3input1.txt, a3input2.txt, a3input3.txt, a3input4.txt, README.txt, tpg.py

To run "a3main.py" on Windows OS:
1) Go to the Windows Command Prompt
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like: python.exe a3main.py a3input1.txt

CREDITS/REFERENCES:
http://docs.python.org/py3k/tutorial/index.html
sbcsppl Q&A group

Notes:
1) For some of the classes representing expressions like Index, there is a comment "# Missing code to return correct expression value #" meaning, the class will not necessarily evaluate to the correct expression as it is not part of this homework. 

2) I created an additional method inList(element, array) which returns True if the given element is within an array, no matter if it's within a sub-array, false otherwise. 

3) I have 2 global variables to represent the list of procedures and variables in the input program. "variables" contains both global and local variables with the former being in the main list, and the latter as a sublist of the main list. This is so repeated local scoping can be achieved.