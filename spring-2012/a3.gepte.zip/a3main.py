import sys
import tpg

class AnalError(Exception):
    """Class of exceptions raised when an error occurs during analysis."""

# These are the classes of nodes of our abstract syntax trees (ASTs).

class Node(object):
    """Base class of AST nodes."""

    # For each class of nodes, store names of the fields for children nodes.
    fields = []

    def __init__(self, *args):
        """Populate fields named in "fields" with values in *args."""
        assert(len(self.fields) == len(args))
        for f, a in zip(self.fields, args): setattr(self, f, a)

    def procAnal(self):
        raise Exception("Not implemented.")

    def varAnal(self):
        raise Exception("Not implemented.")
    
# subclasses of Node for expressions

class Var(Node):
    """Class of nodes representing accesses of variable."""
    fields = ['name']

    def varAnal(self):
        return self.name
    
class Int(Node):
    """Class of nodes representing integer literals."""
    fields = ['value']
    
    def varAnal(self):
        return self.value
    
class String(Node):
    """Class of nodes representing string literals."""
    fields = ['value']

    def varAnal(self):
        return self.value
    
class Array(Node):
    """Class of nodes representing array literals."""
    fields = ['elements']

    def varAnal(self):
        for i in self.elements:
            element = i.varAnal()
            if type(i) is Var and not inList(element, variables): raise AnalError()
            if type(i) is Var and inList(element, variables): print("Use of variable", element)
        return

class Index(Node):
    """Class of nodes representing indexed accesses of arrays or strings."""
    fields = ['indexable','index']

    def varAnal(self):
        indexable = self.indexable.varAnal()
        if type(self.indexable) is Var and not inList(indexable, variables): raise AnalError()
        if type(self.indexable) is Var and inList(indexable, variables): print("Use of variable", indexable)
        index = self.index.varAnal()
        if type(self.index) is Var and not inList(index, variables): raise AnalError()
        if type(self.index) is Var and inList(index, variables): print("Use of variable", index)
        return   # Missing code to return correct expression value #

class BinOpExp(Node):
    """Class of nodes representing binary-operation expressions."""
    fields = ['left', 'op', 'right']

    def varAnal(self):
        left = self.left.varAnal()
        if type(self.left) is Var and not inList(left, variables): raise AnalError()
        if type(self.left) is Var and inList(left, variables): print("Use of variable", left)
        op = self.op
        right = self.right.varAnal()
        if type(self.right) is Var and not inList(right, variables): raise AnalError()
        if type(self.right) is Var and inList(right, variables): print("Use of variable", right)
        return   # Missing code to return correct expression value #
    
class UniOpExp(Node):
    """Class of nodes representing unary-operation expressions."""
    fields = ['op', 'arg']

    def varAnal(self):
        arg = self.arg.varAnal()
        if type(self.arg) is Var and not inList(arg, variables): raise AnalError()
        if type(self.arg) is Var and inList(arg, variables): print("Use of variable", arg)
        op = self.op
        return   # Missing code to return correct expression value #

# subclasses of Node for statements

class Print(Node):
    """Class of nodes representing print statements."""
    fields = ['exp']

    def procAnal(self):
        return

    def varAnal(self):
        exp = self.exp.varAnal()
        if type(self.exp) is Var and not inList(exp, variables): raise AnalError()
        if type(self.exp) is Var and inList(exp, variables): print("Use of variable", exp)
        return

class Assign(Node):
    """Class of nodes representing assignment statements."""
    fields = ['left', 'right']

    def procAnal(self):
        return

    def varAnal(self):
        right = self.right.varAnal()
        if type(self.right) is Var and not inList(right, variables): raise AnalError()
        if type(self.right) is Var and inList(right, variables): print("Use of variable", right)
        left = self.left.varAnal()
        if type(self.left) is Var and not inList(left, variables):
            if not not variables and type(variables[-1]) is list:  # another local variable
                variables[-1].append(left)
            else:  # new global variable
                variables.append(left)
            print("Definition of variable", left)
        elif type(self.left) is Var and inList(left, variables):
            print("Defintion of variable", left)
        return
    
class Block(Node):
    """Class of nodes representing block statements."""
    fields = ['stmts']

    def procAnal(self):
        for i in self.stmts: i.procAnal()
        return
    
    def varAnal(self):
        for i in self.stmts: i.varAnal()
        return

class If(Node):
    """Class of nodes representing if statements."""
    fields = ['exp', 'stmt']

    def procAnal(self):
        self.stmt.procAnal()
        return

    def varAnal(self):
        exp = self.exp.varAnal()
        if type(self.exp) is Var and not inList(exp, variables): raise AnalError()
        if type(self.exp) is Var and inList(exp, variables): print("Use of variable", exp)
        stmt = self.stmt.varAnal()
        return

class While(Node):
    """Class of nodes representing while statements."""
    fields = ['exp', 'stmt']

    def procAnal(self):
        self.stmt.procAnal()
        return

    def varAnal(self):
        exp = self.exp.varAnal()
        if type(self.exp) is Var and not inList(exp, variables): raise AnalError()
        if type(self.exp) is Var and inList(exp, variables): print("Use of variable", exp)
        stmt = self.stmt.varAnal()
        return

class Def(Node):
    """Class of nodes representing procedure definitions."""
    fields = ['name', 'params', 'body']

    def procAnal(self):
        if self.name in procedures: raise AnalError()  # check if procedure is being defined again
        procedures.append(self.name)
        print("Definition of procedure", self.name)
        self.body.procAnal()
        return

    def varAnal(self):
        print("New locals of procedure {}:".format(self.name), ", ".join(self.params))
        for i in self.params:
            if i in variables: raise AnalError()  # check for global variable shadowing
        variables.append(self.params)  # add a "local" sub list to variables
        self.body.varAnal()
        variables.pop()  # remove the local variables after procedure call
        return

class Call(Node):
    """Class of nodes representing precedure calls."""
    fields = ['name', 'args']

    def procAnal(self):
        if self.name not in procedures: raise AnalError()  # check if procedure is defined
        print("Call of procedure", self.name)
        return

    def varAnal(self):
        for i in self.args: i.varAnal()
        return

class Parser(tpg.Parser):
    r"""
    token int:         '\d+' ;
    token string:      '\"[^\"]*\"' ;
    token ident:       '[a-zA-Z_][\w]*' ;
    separator spaces:  '\s+' ;
    separator comment: '#.*' ;

    START/s -> Stmt/s ;

    Stmt/s ->
    ( 'print' Exp/e ';'  $s = Print(e)$
    | Exp/l '=(?!=)' Exp/r ';'  $ s = Assign(l, r) $
    | '\{'  $ s=[] $  ( Stmt/s2  $ s.append(s2) $  )* '\}'  $s=Block(s)$
    | 'if' '\(' Exp/e '\)' Stmt/s  $ s = If(e, s) $
    | 'while' '\(' Exp/e '\)' Stmt/s  $ s = While(e, s) $

    | 'def' ident/f '\('  $l=[]$  ( ident/i  $l.append(i)$
                                    ( ',' ident/i  $l.append(i)$  )*)? '\)'
      Stmt/s2  $s=Def(f,l,s2)$
    | ident/f '\('  $l=[]$  ( Exp/e  $l.append(e)$
                              ( ',' Exp/e  $l.append(e)$  )*)? '\)' ';'
      $s=Call(f,l)$
    ) ;

    Exp/e -> Or/e ;
    Or/e -> And/e ( 'or' And/e2  $e=BinOpExp(e,'or',e2)$  )* ;
    And/e -> BoolAtom/e ( 'and' BoolAtom/e2  $e=BinOpExp(e,'and',e2)$  )* ;
    BoolAtom/e -> 'not' BoolAtom/e $e=UniOpExp('not', e)$  | Test/e ;
    Test/e -> Add/e ( TestOp Add/e2  $e=BinOpExp(e,TestOp,e2)$  )* ;
    Add/e -> Mul/e ( AddOp Mul/e2  $e=BinOpExp(e,AddOp,e2)$  )* ; 
    Mul/e -> Index/e ( MulOp Index/e2  $e=BinOpExp(e,MulOp,e2)$  )* ;
    Index/e -> Atom/e ( '\[' Exp/e2 '\]'  $e=Index(e,e2)$  )* ;
    Atom/e -> 
    '\(' Exp/e '\)'
    | int/i  $e=Int(int(i))$
    | string/s  $e=String(s[1:-1])$
    | '\['  $e=[]$  ( Exp  $e.append(Exp)$  ( ',' Exp  $e.append(Exp)$  )*)?
      '\]'  $e=Array(e)$
    | ident  $e=Var(ident)$
    ;
    TestOp/r ->  '=='/r | '<'/r | '>'/r ;
    AddOp/r ->   '\+'/r | '-'/r ;
    MulOp/r ->   '\*'/r | '/'/r ;
    """

def parse(code):
    # This makes a parser object, which acts as a parsing function.
    parser = Parser()
    return parser(code)

def inList(element, array):
    # Method that checks if an element is in a list regardless if it's in a sublist
    for i in array:
        if type(i) is list: return inList(element, i)
        if element == i: return True
    return False

# Below is the driver code, which parses a given MustScript program
# and analyzes the definitions and uses of procedures and variables

# Open the input file, and read in the input program.
prog = open(sys.argv[1]).read()

try:
    # Try to parse the program.
    print('Parsing...')
    node = parse(prog)

    # Try to analyze the program.
    print('Analyzing...')
    
    # ... set up and call method for analyzing procedures here
    procedures = []
    node.procAnal()

    # ... set up and call method for analyzing variables here
    variables = []
    node.varAnal()

# If an exception is rasied, print the appropriate error.
except tpg.Error:
    print('Parsing Error')

    # Uncomment the next line to re-raise the parsing error,
    # displaying where the error occurs.  Comment it for submission.

    # raise

except AnalError as e:
    print('Analysis Error')

    # Uncomment the next line to re-raise the evaluation error, 
    # displaying where the error occurs.  Comment it for submission.

    # raise
