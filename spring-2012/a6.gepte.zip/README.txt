+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#6          |
|	 Due: 05/02/12         |
+==============================+

This zip file contains: a6main.P, a6input1.P, a6input2.P, a6input3.P, README.txt.

To run "a6main.P" under XSB 3.3 in Cygwin:
1) Run Cygwin.
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like:

	./xsb -e "[a6input1],[a6main],a6run,halt."


CREDITS/REFERENCES:
http://xsb.sourceforge.net/
in-class discussion

NOTES:
1) Numbers 1-6 of the homework were done in class. I merely had to type them in.
2) For numbers 7 & 8, it proved to be helpful to graph the links and nodes of the input files and understand what is to be printed for each query.
3) I made a couple of mistakes regarding the use of tabling which made my program run really slow and gave me a "query exhausted" error. This made me realize the importance of this function.
4) I installed XSB using Cygwin in my Windows OS, following the configure and makexsb commands.
5) The output of my program may not print the nodes in the same order as with the sample output files posted in the homework page. They are, however, the same nodes.

