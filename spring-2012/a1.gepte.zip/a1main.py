def numRows(list):
    """ Returns the number of rows given a type list.
        It also deletes any empty rows. """
    emptyRows = []
    for i in range(len(list)):
        if isEmptyRow(list[i]):
            emptyRows.append(i)
    emptyRows.reverse()     #reverse necessary to avoid index out of bounds when deleting
    for i in range(len(emptyRows)):
        del list[emptyRows[i]]      #delete empty rows
    return len(list)

def numColumns(list):
    """ Returns the number of columns given a type list. """
    for i in range(len(list)-1):
        if (not isEmptyRow(list[i]) and not isEmptyRow(list[i+1])):
            if len(list[i]) != len(list[i+1]):
                return -1
    return len(list[0])

def isEmptyRow(list):
    """ Determines if a type list is empty. """
    nonEmptyCell = 0
    for i in range(len(list)):
        if len(list[i]) > 0:
            nonEmptyCell += 1
    if nonEmptyCell == 0:
        return True
    else:
        return False

def columnValues(list):
    """ Returns a list with these properties:
        list[0]: list of column headers
        list[1~]: corresponding column data """
    aList, bList = [], []
    aList.append(list[0])
    del list[0]
    for i in range(len(aList[0])):
        cList = []
        for j in range(len(list)):
            cList.append(list[j][i])
        bList.append(cList)
    aList[len(aList):] = bList
    return aList

def printColumnData(num, name, data):
    """ Prints a column of data given the parameters. """
    print("Column %d: %s" %(num, name))
    cnt = {}
    for i in set(data):
        cnt[i] = data.count(i)
    for name, count in sorted(cnt.items()):
       print(" {} {}".format(count, name))

def convertStringToInt(list):
    for x in list:
        list[list.index(x)] = int(x)
    return list

if __name__ == "__main__":
    import sys
    data = open(sys.argv[1],'rU').read()                #read in input data
    lines = data.split('\n')                            #split data into lines
    for i in range(len(lines)):                         #split lines into cells
        lines[i] = lines[i].split('\t')
    print("Number of rows:", numRows(lines))            #prints number of rows
    if numColumns(lines) != -1:
        print("Number of columns:", numColumns(lines))  #prints number of columns
    else:
        print("Cannot determine number of columns")
        sys.exit(0)
    lines = columnValues(lines)                         #groups lists by column
    for x in lines:                                     #convert from string to int
        try:
            x = convertStringToInt(x)
        except:
            pass
    for i in range(1, len(lines)):                      #print each column
        printColumnData(i-1, lines[0][i-1], lines[i])
