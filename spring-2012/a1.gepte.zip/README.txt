+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#1          |
|	 Due: 02/07/12         |
+==============================+

This zip file contains: a1main.py, a1input1.txt, a1input2.txt, a1input3.txt, a1input4.txt, a1input5.txt, README.txt


To run "a1main.py" on Windows OS:
1) Go to the Windows Command Prompt
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like: python.exe a1main.py a1input1.txt


CREDITS/REFERENCES:
http://docs.python.org/py3k/tutorial/index.html
http://docs.python.org/faq/windows.html#how-do-i-run-a-python-program-under-windows


NOTES:
I found using a try/catch block necessary for converting the string values into int. I considered using Count from the Collections class to count the number of occurences in a list but I found another way using a simple dictionary; it eliminated importing Collections. The tutorial from python.org proved to be very helpful in every way: from setting up python to coding.