+==============================+
|@author Dinia Gepte, 107092681|
|	 CSE 307-01            |
|	 Assignment#2          |
|	 Due: 02/21/12         |
+==============================+

This zip file contains: a2main.py, a2input1.txt, README.txt, tpg.py

To run "a2main.py" on Windows OS:
1) Go to the Windows Command Prompt
2) Go to the directory in which all associated files are saved.
3) Run the program using a command like: python.exe a2main.py a2input1.txt


CREDITS/REFERENCES:
http://docs.python.org/py3k/tutorial/index.html
http://cdsoft.fr/tpg/tpg.pdf
Programming Languages Pragmatics (Scott)


NOTES:
I started off the homework by reading through the textbook/slides/tpg documentation to give me a good idea on how to do it. The way I approached the actual homework was to build the classes bottom-up: starting with data types, operators, then grammar. To test my classes independently, I used the Python command line. For the grammar test, I used the Windows command line.