import sys
import tpg

class EvalError(Exception):
    """Class of exceptions raised when an error occurs during evaluation."""

# These are the classes of nodes of our abstract syntax trees (ASTs).

class Node(object):
    """Base class of AST nodes.  May come in handy in the future."""
    
    def eval(self):
        """Evaluate the AST node, called on nodes of subclasses of Node."""
        raise Exception("Not implemented.")

class Int(Node):
    """Class of nodes representing integer literals."""

    def __init__(self, value):
        self.value = int(value)
    
    def eval(self):
        return self.value

class String(Node):
    """Class of nodes representing string literals"""

    def __init__(self, value):
        self.value = str(value)

    def eval(self):
        return self.value.strip('"')

class Array(Node):
    """Class of nodes representing array literals"""

    def __init__(self, value):
        self.value = value

    def eval(self):
        values = self.value
        if len(values) == 0: return []
        return values

class Index(Node):
    def __init__(self, a, index):
        self.a = a
        self.index = index

    def eval(self):
        a = self.a.eval()
        index = self.index.eval()
        if not isinstance(a,str) and not isinstance(a,list): raise EvalError()  #REPLACE list WITH Array?
        if not isinstance(index,int): raise EvalError()
        if (index >= len(a)) or (index < 0): raise EvalError()
        return a[index]

class Multiply(Node):
    """Class of nodes representing integer multiplications."""

    def __init__(self, left, right):
        # The nodes representing the left and right sides of this operation.
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        return left * right

class Divide(Node):
    """Class of nodes representing integer divisions."""

    def __init__(self, left, right):
        # The nodes representing the left and right sides of this operation.
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        if right == 0: raise EvalError()
        return int(left / right)

class Add(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if (not isinstance(left,int) or not isinstance(right,int)) and (not isinstance(left,str) or not isinstance(right,str)): raise EvalError()
        return left + right
    
class Subtract(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        return left - right

class Compare(Node):
    def __init__(self, left, right, comparator):
        self.left = left
        self.right = right
        self.comparator = comparator

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        comparator = self.comparator
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        if comparator == "<" and left < right: return 1
        if comparator == "==" and left == right: return 1
        if comparator == ">" and left > right: return 1
        return 0

class Negate(Node):
    def __init__(self, a):
        self.a = a

    def eval(self):
        a = self.a.eval()
        if not isinstance(a,int): raise EvalError()
        if a == 0: return 1
        return 0

class Conjunction(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        if left == 0 or right == 0: return 0
        return 1

class Disjunction(Node):
    def __init__(self, left, right):
        self.left = left
        self.right = right

    def eval(self):
        left = self.left.eval()
        right = self.right.eval()
        if not isinstance(left,int): raise EvalError()
        if not isinstance(right,int): raise EvalError()
        if left == 0 and right == 0: return 0
        return 1

# This is the parser using TPG for parsing expressions and building an AST.
class Parser(tpg.Parser):
    r"""
    token int:         '\d+' ;
    token string:      '\"[^\"]*\"' ;
    separator spaces:  '\s+' ;

    START/s -> Dis/s ( 'or' Dis/s2 $s=Disjunction(s,s2)$ )* ;
    Dis/e -> Con/e ( 'and' Con/e2 $e=Conjunction(e,e2)$ )* ;
    Con/e -> Comp/e | 'not' Con/e $e=Negate(e)$ ;
    Comp/e -> Exp/e ( '<' Exp/e2 $e=Compare(e,e2,"<")$
                    | '>' Exp/e2 $e=Compare(e,e2,">")$
                    | '==' Exp/e2 $e=Compare(e,e2,"==")$ )* ;
    Exp/e -> MulDiv/e ( '\+' MulDiv/e2 $e=Add(e,e2)$
                      | '\-' MulDiv/e2 $e=Subtract(e,e2)$ )* ;
    MulDiv/e -> Index/e ( '\*' Index/e2  $e=Multiply(e,e2)$
                        | '/'  Index/e2  $e=Divide(e,e2)$ )* ;
    Index/e -> Atom/e ( '\[' Exp/e2 '\]' $e=Index(e,e2)$ )* | Atom/e ;
    Atom/e -> '\(' Exp/e '\)'
              | int/i  $e=Int(int(i))$  
              | string/s  $e=String(str(s))$
              | ('\[' ('\]' $e=Array([])$ | List/l '\]' $e=Array(l)$)) ;
    List/e ->        $e=[]$
              Exp/a  $e.append(a.eval())$
             ( ',' Exp/a  $e.append(a.eval())$ )* ;
    """

# This makes a parser object, which acts as a parsing function.
parser = Parser()


# Below is the driver code, which reads in lines, deals with errors, and
# prints the evaluation result if no error occurs.

# Open the input file, and read in lines of the file.
lines = open(sys.argv[1], 'r').readlines()

# For each line in the input file
for l in lines:
    # Uncomment the next line to help testing.  Comment it for submission.
    # print(l, end="")
    try:
        # Try to parse the expression.
        node = parser(l)

        # Try to evaluate the expression.
        result = node.eval()

        # Print the representation of the result.
        print(repr(result))

    # If an exception is rasied, print the appropriate error.
    except tpg.Error:
        print('Parsing Error')

        # Uncomment the next line to re-raise the parsing error,
        # displaying where the error occurs.  Comment it for submission.

        # raise

    except EvalError:
        print('Evaluation Error')

        # Uncomment the next line to re-raise the evaluation error, 
        # displaying where the error occurs.  Comment it for submission.

        # raise
