/*
	See Hit.h for description.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"
#include "Hit.h"

Hit::Hit(string ip, string link, string date)
{
	// CHECK FOR IP ADDRESS
	int length = ip.length();
	if (length > 15)
		throw invalid_argument("invalid ip address (exceeds 15 characters)");
	ipAddress = ip.substr(0, 15);	// IP ADDRESS HAS A MAXIMUM OF 15 CHARACTERS: xxx.xxx.xxx.xxx

	// CHECK FOR LINK NAME
	length = link.length();
	linkName = link.substr(0, MAX_LINK_SIZE);	// LINK NAME ONLY TAKES A MAXIMUM OF 50 CHARACTERS, AND DISCARDS THE REST

	// CHECK FOR DATE ACCESSED
	length = date.length();
	if (length > 10)
		throw invalid_argument("invalid date format (not mm/dd/yyy)");
	istringstream iss(date);
	string dateElement;
	int num[3];
	for (int i = 0; getline(iss, dateElement, '/'); i++)
	{
		if (dateElement.length() == 2 || dateElement.length() == 4)
			num[i] = stoi(dateElement, nullptr);
		else
			throw invalid_argument("invalid date format (not mm/dd/yyy)");
	}
	dateAccessed = Date(num[0], num[1], num[2]);
}

/*
	Prints this object, displaying its IP_Address followed by Link_Name, 
	then by Date_Accessed.
*/
void Hit::print() const
{
	cout << ipAddress << ' ' << linkName << ' ';
	dateAccessed.print();
}