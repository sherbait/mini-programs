/**
 This program sccepts a text file containing information about
 a series of hits to various websites. It then stores this
 information and will provide the user with a menu that will
 look up information about a website of his or her choosing.

 The format for the input file is:
 (IP_Address) (Link_Name) (Date_Accessed)

 > IP_Address is the IP Address of the user which does not contain any spaces.
 > Link_Name is the name of the website that does not contain any spaces (max 50 chars)
 > Date_Accessed is the date of the hit in mm/dd/yyyy format (Ex: 07/06/2013)

 Assignment #4 for CSE230, SPR13, SBU
 IDE & Compiler: Microsoft Visual Studio 2010

 @author Dinia Gepte
		 107092681
		 dingepte@gmail.com
 */
#include "stdafx.h"
#include "HitList.h"

int main()
{
	// STORES ALL VALID HITS WE READ FROM A FILE
	HitList *hits = new HitList();
	
	// THIS LOOP READS THE FILE
	while (true)
	{
		string fileName, line, value;

		// ASK THE USER FOR A FILE NAME
		cout << "Enter the name of a file to load: ";
		cin >> fileName;
		ifstream hitsFile(fileName);

		// IS THE FILE READY FOR READING?
		if (hitsFile.is_open())
		{
			cout << "Loading " << fileName << "...\n" << endl;

			// READ THE FILE UNTIL WE REACH THE END
			while (hitsFile.good())
			{
				// GET EACH LINE IN THE FILE
				getline(hitsFile, line);
				istringstream issHit(line);
				try {
					// THIS WILL HOLD THE DATA IN EACH LINE
					vector<string> hitValues;

					// TOKENIZE THE LINE SEPARATED BY SPACES
					while (getline(issHit, value, ' '))
						hitValues.push_back(value);

					// DO WE HAVE 3 VALUES (IP_ADDRESS, LINK_NAME, DATE_ACCESSED)?
					if (hitValues.size() != 3)
						throw invalid_argument("invalid number of values (need 3 arguments)");

					// TRY AND CREATE A Hit OBJECT
					Hit *hit = new Hit(hitValues.at(0), hitValues.at(1), hitValues.at(2));

					// SUCCESSFULLY CREATED A Hit OBJECT. NOW ADD IT INTO OUR HIT LIST
					hits->addHit(hit);

				} catch (exception e) {
					cout << "Found a record with an " << e.what() << "... ignoring entry" << endl;
				}	
			}
			
			// WE HAVE SUCCESSFULLY READ ALL DATA FROM THE FILE.
			// CLOSE THE FILE THEN GET OUT OF THE LOOP
			hitsFile.close();
			break;
		}
		else
		{
			cout << "Unable to load file... please try again\n" << endl;
		}
	}

	// PROVIDE THE USER WITH A MENU THAT WILL LOOK UP
	// INFORMATION ABOUT A WEBSITE OF HIS/HER CHOOSING
	string option = "";
	while (option.compare("3") != 0)
	{
		cout << endl;
		cout << "Please select a menu option:\n";
		cout << "1) Link Information in date range\n";
		cout << "2) Information about all links\n";
		cout << "3) Quit the program\n";
		cout << "Option (1,2,3): ";
		cin >> option;

		// REPORT INFORMATION ABOUT HITS FOR A GIVEN LINK IN A PERIOD OF TIME
		if (option.compare("1") == 0)
		{
			cout << endl;
			string linkName, beginDate, endDate;
			Date bDate, eDate;

			do	// IS THE LINK IN THE INPUT FILE?
			{
				cout << "Enter a link name: ";
				cin >> linkName;
				if (!hits->contains(linkName))
					cout << "Link name is not in input file... please try again\n";
			} while (!hits->contains(linkName));

			do // READ IN DATES FROM THE USER
			{
				do	// START DATE
				{
					cout << "Enter a start date (mm/dd/yyyy): ";
					cin >> beginDate;
					if (!bDate.isDateValid(beginDate))
						cout << "Invalid date... please re-enter information\n";
				} while (!bDate.isDateValid(beginDate));
				
				do // END DATE
				{
					cout << "Enter a finish date (mm/dd/yyyy): ";
					cin >> endDate;
					if (!eDate.isDateValid(endDate))
						cout << "Invalid date... please re-enter information\n";
				} while (!eDate.isDateValid(endDate));

				// NEEDED FOR COMPARING BEGIN DATE AND END DATE
				int month = stoi(beginDate.substr(0,2));
				int day = stoi(beginDate.substr(3,2));
				int year = stoi(beginDate.substr(6));
				bDate = Date(month, day, year);

				month = stoi(endDate.substr(0,2));
				day = stoi(endDate.substr(3,2));
				year = stoi(endDate.substr(6));
				eDate = Date(month, day, year);

				if (eDate.compare(bDate) < 0)
					cout << "Dates out of order... please re-enter information\n";

			} while (eDate.compare(bDate) < 0);

			// PRINT THE INFORMATION
			cout << endl;
			cout << "Link: " << linkName << endl;
			cout.width(15);
			cout << left << "Total hits: ";
			cout << hits->getTotalHits(linkName, bDate, eDate) << endl;
			cout.width(15);
			cout << "Unique: ";
			cout << hits->getUniqueVisitors(linkName, bDate, eDate) << endl;
			cout.width(15);
			cout << "Returning: ";
			cout << hits->getReturningVisitors(linkName, bDate, eDate) << endl;
		}
		// PRINT THE INPUT INFORMATION FROM THE TEXT FILE BASED UPON
		// NUMBER OF UNIQUE VISITORS TO EACH WEBSITE (IN INCREASING ORDER)
		else if (option.compare("2") == 0)
		{
			cout << endl;
			hits->printListByUniqueVisitor();
			cout << endl;
		}
		// QUIT THE PROGRAM
		else if (option.compare("3") == 0)
			cout << "\nProgram terminating normally..." << endl;
		// USER ENTERED A WRONG VALUE
		else
			cout << "Invalid option... please try again\n" << endl;
	}

	return 0;
}