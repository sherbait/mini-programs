/*
	See HitList.h for description.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"
#include "HitList.h"

struct sorter {
  bool operator() (Website const &w1, Website const &w2) { return w1.uniqueVisitors < w2.uniqueVisitors; }
} uniqueSorter;

/*
	Adds the object to the hit list.
*/
void HitList::addHit(Hit *hitToAdd)
{
	hits.push_back(hitToAdd);
}

/*
	Determines if the given hitName (i.e. website/link name) 
	is in the hit list. Returns true if it is, otherwise false.
*/
bool HitList::contains(string hitName)
{
	list<Hit*>::iterator hitIterator;
	hitIterator = hits.begin();
	while (hitIterator != hits.end())
	{
		Hit *hit = *hitIterator;
		if (hitName.compare(hit->getLinkName()) == 0)
			return true;
		hitIterator++;
	}
	return false;
}

/*
	Counts the number of hits by returning visitors
	(number of visits beyong the first visitors) to
	the given website.
 */
int HitList::getReturningVisitors(string website)
{
	// HAS THE WEBSITE BEEN VISITED BEFORE?
	if (isWebsiteInHitList(website))
	{
		map<string, int> visitors;
		int count = 0;

		// IF SO, ITERATE THROUGH THE WHOLE LIST
		list<Hit*>::iterator hitIterator;
		hitIterator = hits.begin();
		while (hitIterator != hits.end())
		{
			Hit *hit = *hitIterator;
			// WE'RE ONLY INTERESTED IN THE HITS OF website.
			// HOW MANY TIMES DID A VISITOR VISIT?
			if (website.compare(hit->getLinkName()) == 0)
			{
				visitors[hit->getIpAddress()] += 1;
			}
			hitIterator++;
		}

		// COUNT THE NUMBER OF VISITS BEYOND THE FIRST BY VISITORS
		map<string, int>::iterator visitorIterator = visitors.begin();
		while (visitorIterator != visitors.end())
		{
			if (visitorIterator->second > 1)
			{
				// WE DO NOT INLCUDE THE FIRST VISIT IN THE COUNT
				count += visitorIterator->second - 1;
			}
			visitorIterator++;
		}

		return count;
	}
	
	// website IS NOT IN THE LIST SO NO ONE HAS VISITED IT
	return 0;
}

/*
	Counts the number of hits by unique visitors (the number of visits
	beyond the first by visitors) to the given website. In addition,
	this function accepts a start date and end date that filters the
	hits, and selects only those hits that fall in between the 2 dates.

	Returns -1 if the start date is later than the begin date.
	Otherwise, returns the number of visitors within the given time frame.
*/
int HitList::getReturningVisitors(string website, Date startDate, Date endDate)
{
	// STARTDATE MUST BE OLDER OR THE SAME DATE THAN ENDDATE
	if (startDate.compare(endDate) > 0)
		return -1;

	// HAS THE WEBSITE BEEN VISITED BEFORE?
	if (isWebsiteInHitList(website))
	{
		map<string, int> visitors;
		int count = 0;

		// IF SO, ITERATE THROUGH THE WHOLE LIST
		list<Hit*>::iterator hitIterator;
		hitIterator = hits.begin();
		while (hitIterator != hits.end())
		{
			Hit *hit = *hitIterator;
			// WE'RE ONLY INTERESTED IN THE HITS OF website.
			// HOW MANY TIMES DID A VISITOR VISIT DURING THE TIME FRAME?
			if (website.compare(hit->getLinkName()) == 0)
			{
				if ((startDate.compare(hit->getDateAccessed()) <= 0) && (endDate.compare(hit->getDateAccessed()) >= 0))
					visitors[hit->getIpAddress()] += 1;
			}
			hitIterator++;
		}

		// COUNT THE NUMBER OF VISITS BEYOND THE FIRST BY VISITORS
		map<string, int>::iterator visitorIterator = visitors.begin();
		while (visitorIterator != visitors.end())
		{
			if (visitorIterator->second > 1)
			{
				// WE DO NOT INLCUDE THE FIRST VISIT IN THE COUNT
				count += visitorIterator->second - 1;
			}
			visitorIterator++;
		}

		return count;
	}
	
	// website IS NOT IN THE LIST SO NO ONE HAS VISITED IT
	return 0;
}

/*
	Counts the number of total hits (times that the link was visited altogether)
	of the given website.
*/
int HitList::getTotalHits(string website)
{
	return getUniqueVisitors(website) + getReturningVisitors(website);
}

/*
	Counts the number of total hits (times that the link was visited althogether)
	of the given website within the period of time.

	Returns a negative number if the start date is later than the end date.
	Otherwise, returns the number of visitors within the given time frame.
*/
int HitList::getTotalHits(string website, Date startDate, Date endDate)
{
	return getUniqueVisitors(website, startDate, endDate) + getReturningVisitors(website, startDate, endDate);
}

/*
	Counts the number of hits by unique visitors (the number of visitors who
	visited the link, not counting duplicate visits) of the given website.
*/
int HitList::getUniqueVisitors(string website)
{
	// HAS THE WEBSITE BEEN VISITED BEFORE?
	if (isWebsiteInHitList(website))
	{
		map<string, int> visitors;

		// IF SO, ITERATE THROUGH THE WHOLE LIST
		list<Hit*>::iterator hitIterator;
		hitIterator = hits.begin();
		while (hitIterator != hits.end())
		{
			Hit *hit = *hitIterator;
			// WE'RE ONLY INTERESTED IN THE HITS OF website.
			// HOW MANY TIMES DID A VISITOR VISIT?
			if (website.compare(hit->getLinkName()) == 0)
			{
				visitors[hit->getIpAddress()] += 1;
			}
			hitIterator++;
		}

		return visitors.size();
	}
	
	// website IS NOT IN THE LIST SO NO ONE HAS VISITED IT
	return 0;
}

/*
	Counts the number of hits by unique visitors (the number of visitors who
	visited the link, not counting duplicate visits) of the given website.
	In addition, this function accepts a start date and end date that filters the
	hits, and selects only those hits that fall in between the 2 dates.

	Returns -1 if the start date is later than the begin date.
	Otherwise, returns the number of visitors within the given time frame.
*/
int HitList::getUniqueVisitors(string website, Date startDate, Date endDate)
{
	// STARTDATE MUST BE OLDER OR THE SAME DATE THAN ENDDATE
	if (startDate.compare(endDate) > 0)
		return -1;

	// HAS THE WEBSITE BEEN VISITED BEFORE?
	if (isWebsiteInHitList(website))
	{
		map<string, int> visitors;

		// IF SO, ITERATE THROUGH THE WHOLE LIST
		list<Hit*>::iterator hitIterator;
		hitIterator = hits.begin();
		while (hitIterator != hits.end())
		{
			Hit *hit = *hitIterator;
			// WE'RE ONLY INTERESTED IN THE HITS OF website.
			// HOW MANY TIMES DID A VISITOR VISIT DURING THE TIME FRAME?
			if (website.compare(hit->getLinkName()) == 0)
			{
				if ((startDate.compare(hit->getDateAccessed()) <= 0) && (endDate.compare(hit->getDateAccessed()) >= 0))
					visitors[hit->getIpAddress()] += 1;
			}
			hitIterator++;
		}

		return visitors.size();
	}
	
	// website IS NOT IN THE LIST SO NO ONE HAS VISITED IT
	return 0;
}

/*
	Prints a table that shows all the websites and a report information.
	The report information contains: total hits, unique visits, duplicate
	visits. Furthermore, this function sorts the information according to
	the number of unique visitors (in increasing order).
*/
void HitList::printListByUniqueVisitor()
{
	// PRINT A HEADER FOR THIS TABLE
	printHeader();
	
	// FIND THE UNIQUE WEBSITES
	set<string> links;

	// ITERATE THROUGH THE LIST, CHECKING THE UNIQUE LINKS
	list<Hit*>::iterator hitIterator;
	hitIterator = hits.begin();
	while (hitIterator != hits.end())
	{
		Hit *hit = *hitIterator;
		links.insert(hit->getLinkName());
		hitIterator++;
	}

	// WE SHOULD PRINT THE TABLE IN INCREASING ORDER BASED ON UNIQUE VISITOR COUNT
	vector<Website> websites;

	// ITERATE THROUGH THE UNIQUE WEBSITES
	set<string>::iterator linkIterator;
	linkIterator = links.begin();
	while (linkIterator != links.end())
	{
		string name = *linkIterator;
		Website website;
		website.name.append(name);
		website.returnVisitors = this->getReturningVisitors(name);
		website.totalVisitors = this->getTotalHits(name);
		website.uniqueVisitors = this->getUniqueVisitors(name);
		websites.push_back(website);
		linkIterator++;
	}
	
	// NOW SORT THE WEBSITES ACCORDING TO THE UNIQUE VISITS, IN INCREASING ORDER
	sort(websites.begin(), websites.end(), uniqueSorter);
	
	// PRINT THE RESULTS
	for (int i = 0 ; i < websites.size(); i++)
	{
		cout.width(32);
		cout << left << websites.at(i).name.substr(0, 32);	// ONLY PRINT THE FIRST 32 CHARACTERS
		printChar(3, ' ');
		cout.width(7);
		cout << right << websites.at(i).uniqueVisitors;
		printChar(9, ' ');
		cout.width(7);
		cout << right << websites.at(i).returnVisitors;
		printChar(9, ' ');
		cout.width(6);
		cout << right << websites.at(i).totalVisitors;
		cout << endl;
	}
}

/*
	Helper method that prints n number of char c in a single line.
*/
void HitList::printChar(int n, char c)
{
	while (n > 0)
	{
		cout << c;
		n--;
	}	
}

/*
	Helper method that prints a table header that displays:

		Link Name		Unique Visits	Return Visits	Total Visits
	----------------	-------------	-------------	------------
*/
void HitList::printHeader()
{
	// HEADER
	cout.width(20);
	cout << "Link Name";
	printChar(15, ' ');
	cout << "Unique Visits";
	printChar(3, ' ');
	cout << "Return Visits";
	printChar(3, ' ');
	cout << "Total Visits";
	cout << endl;

	// BORDER
	printChar(32, '-');
	printChar(3, ' ');
	printChar(13, '-');
	printChar(3, ' ');
	printChar(13, '-');
	printChar(3, ' ');
	printChar(12, '-');
	cout << endl;
}

/*
	See contains(string hitName).
*/
bool HitList::isWebsiteInHitList(string website)
{
	list<Hit*>::iterator hitIterator;
	hitIterator = hits.begin();
	while (hitIterator != hits.end())
	{
		Hit *hit = *hitIterator;
		if (website.compare(hit->getLinkName()) == 0)
			return true;
		hitIterator++;
	}

	// WEBSITE IS NOT IN THE LIST
	return false;
}