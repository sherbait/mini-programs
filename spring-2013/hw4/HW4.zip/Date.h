/*
	This class represents a date in mm/dd/yyyy format.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"

#ifndef DATE_H
#define DATE_H
class Date {
public:
	// CONSTRUCTOR AND DESTRUCTOR
	Date(int = 1, int = 1, int = 1900);
	~Date() {}

	// INLINE ACCESSOR METHODS
	int getMonth()	{ return month;	}
	int getDay()	{ return day;	}
	int getYear()	{ return year;	}

	// PUBLIC METHODS
	int compare(Date d);
	void print() const;
	static bool isDateValid(string s);
	
private:
	int month;	// 1-12
	int day;	// 1-31 based on month
	int year;	// any year
	int checkDay(int);
};
#endif