/*
	This class contains a collection of Hits and provides various functions
	that gives information about the hits.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"
#include "Hit.h"
#include "Date.h"

#ifndef HITLIST_H
#define HITLIST_H

struct Website {
	string name;
	int uniqueVisitors;
	int returnVisitors;
	int totalVisitors;
};

class HitList {
public:
	// CONSTRUCTOR & DESTRUCTOR
	HitList() {}
	~HitList() {}

	// PUBLIC METHODS
	void addHit(Hit *hitToAdd);
	bool contains(string hitName);
	int getReturningVisitors(string website);
	int getReturningVisitors(string website, Date startDate, Date endDate);
	int getTotalHits(string website);
	int getTotalHits(string website, Date startDate, Date endDate);
	int getUniqueVisitors(string website);
	int getUniqueVisitors(string website, Date startDate, Date endDate);
	void printListByUniqueVisitor();

private:
	// VARIABLES
	list<Hit*> hits;

	// HELPER METHODS
	bool isWebsiteInHitList(string website);
	void printChar(int n, char c);
	void printHeader();
};
#endif