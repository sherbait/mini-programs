#include <cstring>
#include <cassert>
#include <iostream>
#include <stdexcept>
#include <sstream>
#include <fstream>
#include <list>
#include <map>
#include <set>
#include <vector>
#include <algorithm>

using namespace std;