/*
	This class represents a hit in a website.
	It contains an IP Address, Link Name (website),
	and Date Accessed fields.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"
#include "Date.h"

#ifndef HIT_H
#define HIT

const int MAX_LINK_SIZE = 50;

class Hit {
public:
	// CONSTRUCTOR & DESTRUCTOR
	Hit(string ip, string link, string date);
	~Hit() {}

	// INLINE ACCESSOR METHODS
	string getIpAddress()		{ return ipAddress;		}
	string getLinkName()		{ return linkName;		}
	Date getDateAccessed()		{ return dateAccessed;	}

	// OTHER METHODS
	void print() const;
	
private:
	string ipAddress;	// xxx.xxx.xxx.xxx
	string linkName;	// MAXIMUM 50 CHARACTERS
	Date dateAccessed;
};
#endif