/*
	See Date.h for description.

	@author Dinia Gepte
			107092681
			dingepte@gmail.com
*/
#include "stdafx.h"
#include "Date.h"

Date::Date(int initMonth, int initDay, int initYear)
{
	if (initMonth > 0 && initMonth <= 12)	// validate the month
	{
		month = initMonth;
	}
	else
	{
		throw invalid_argument("invalid date (wrong month)");
	}

	if (initYear > 0)	// validate the year
	{
		year = initYear;
	}
	else
	{
		throw invalid_argument("invalid date (wrong year)");
	}

	day = checkDay(initDay);	// validate the day

}

/*
	Compares this Date object to another Date object.

	Returns -1 if d1 is older than d2.
	Returns 1 if d1 is younger than d2.
	Returns 0 if the dates are the same.
*/
int Date::compare(Date d)
{
	// TEST FOR YEARS
	if (year < d.getYear())
		return -1;	// d1 IS OLDER THAN d2
	if (year > d.getYear())
		return 1;	// d1 IS YOUNGER THAN d2

	// YEARS ARE EQUAL, SO TEST FOR MONTH
	if (month < d.getMonth())
		return -1;	// d1 IS OLDER THAN d2
	if (month > d.getMonth())
		return 1;	// d1 IS YOUNGER THAN d2

	// MONTHS ARE EQUAL, SO TEST FOR DAY
	if (day < d.getDay())
		return -1;	// d1 IS OLDER THAN d2
	if (day > d.getDay())
		return 1;	// d1 IS YOUNGER THAN d2

	// EVEN DAYS ARE EQUAL, SO IT MUST BE THE SAME DATE
	return 0;
}

/*
	Accepts a string argument and checks whether, by constructing
	it as Date object will be successfully constructed (i.e. no
	errors will be thrown).

	Returns true if it is a valid date, false otherwise.
*/
bool Date::isDateValid(string s)
{
	int length = s.length();
	if (length > 10)
		return false;
	istringstream iss(s);
	string dateElement;
	int num[3];
	for (int i = 0; getline(iss, dateElement, '/'); i++)
	{
		if (dateElement.length() == 2 || dateElement.length() == 4)
		{
			try {
				num[i] = stoi(dateElement);
			} catch (exception e)
			{
				return false;
			}
		}
		else
			return false;
	}
	try {
		Date d(num[0], num[1], num[2]);
	} catch (exception e)
	{
		return false;
	}
	return true;
}

/*
	Prints the date in mm/dd/yyyy format.
 */
void Date::print() const
{
	cout << month << '/' << day << '/' << year << endl;
}

/*
	Checks whether testDay is a valid day in the given month
	and year, assuming that month and year are previously set.
*/
int Date::checkDay(int testDay)
{
	static const int daysPerMonth[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
	if (testDay > 0 && testDay <= daysPerMonth[month])
	{
		return testDay;
	}
	if (month == 2 && testDay == 29 && 
		(year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)))	// test for leap year
	{
		return testDay;
	}
	throw invalid_argument("invalid date (wrong day)");
	return -1;
}